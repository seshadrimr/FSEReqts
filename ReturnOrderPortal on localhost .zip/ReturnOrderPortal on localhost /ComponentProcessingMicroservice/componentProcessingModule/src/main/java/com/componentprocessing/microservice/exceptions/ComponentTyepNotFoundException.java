package com.componentprocessing.microservice.exceptions;



public class ComponentTyepNotFoundException extends RuntimeException{
	
	public ComponentTyepNotFoundException(String message) {
		super(message);
	}

}
