package com.packaging.delivery.exceptions;



public class ComponentTyepNotFoundException extends RuntimeException{
	
	public ComponentTyepNotFoundException(String message) {
		super(message);
	}

}
