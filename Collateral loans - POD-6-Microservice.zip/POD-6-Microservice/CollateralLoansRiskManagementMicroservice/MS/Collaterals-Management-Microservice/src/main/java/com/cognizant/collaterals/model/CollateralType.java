package com.cognizant.collaterals.model;

/**
 * Model class for Collateral Type
 */
public enum CollateralType {

	REAL_ESTATE, CASH_DEPOSIT
}
