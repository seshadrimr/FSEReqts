﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TruYum3.Startup))]
namespace TruYum3
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
