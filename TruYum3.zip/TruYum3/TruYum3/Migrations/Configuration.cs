namespace TruYum3.Migrations
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using Models;

    internal sealed class Configuration : DbMigrationsConfiguration<TruYum3.Models.TruYumContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(TruYum3.Models.TruYumContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            //IList<TruYum3.Models.Category> categories = new List<TruYum3.Models.Category>();
            
            //context.Categories.AddOrUpdate(new Category() { Name = "Main Course" });
            //context.Categories.AddOrUpdate(new Category() { Name = "Dessert" });
            //context.Categories.AddOrUpdate(new Category() { Name = "Starters" });

            //context.Categories.AddRange(categories);

            //base.Seed(context);
        }
    }
}
