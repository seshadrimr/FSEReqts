﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace TruYum3.Models
{
    public class TruYumContext : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx
    
        public TruYumContext() : base("name=TruYumContext")
        {
            Database.SetInitializer(new truYumInitializer());
        }

        public System.Data.Entity.DbSet<TruYum3.Models.MenuItem> MenuItems { get; set; }

        public System.Data.Entity.DbSet<TruYum3.Models.Category> Categories { get; set; }

        public System.Data.Entity.DbSet<TruYum3.Models.Cart> Carts { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }

    public class truYumInitializer : CreateDatabaseIfNotExists<TruYumContext>
    {
        protected override void Seed(TruYumContext context)
        {
            IList<TruYum3.Models.Category> categories = new List<TruYum3.Models.Category>();

            categories.Add(new Category() { Name = "Main Course" });
            categories.Add(new Category() { Name = "Dessert" });
            categories.Add(new Category() { Name = "Starters" });

            context.Categories.AddRange(categories);

            base.Seed(context);
        }
    }
}

