﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TruYum3.Models;
using System.Data.Entity;

namespace TruYum3.Controllers
{
    public class CartController : Controller
    {
        private TruYumContext db = new TruYumContext();
        int _userId = 1;
        // GET: Cart
        public ActionResult Index()
        {
            List<Cart> lstCartItem = db.Carts.Include(iter => iter.MenuItem).Where(iter => iter.userId == _userId).ToList();
            return View(lstCartItem);            
        }

        public ActionResult AddToCart(int menuItemId)
        {
            db.Carts.Add(new Cart()
            {
                userId = _userId,
                menuItemId = menuItemId
            });
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            Cart cartItem = db.Carts.Find(id);
            if (cartItem != null)
            {
                db.Carts.Remove(cartItem);
                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }
    }
}